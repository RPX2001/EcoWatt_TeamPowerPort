/**
 * @file Timers.h
 * @brief Declaration of the PeriodicTimer class for periodic callback execution.
 *
 * @details
 * Defines the PeriodicTimer class, which executes a user-supplied callback function
 * at a fixed interval in a background thread. Supports explicit start and stop operations,
 * and ensures thread-safe periodic execution using a steady clock.
 *
 * @author Prabath (original)
 * @author Yasith (revision)
 * @version 1.1
 * @date 2025-08-18
 *
 * @par Revision history
 * - 1.0 (Prabath, 2025-08-14) Original file.
 * - 1.1 (Yasith, 2025-08-18) Split into header and source files and split to layers.
 */


#pragma once

#include <atomic>
#include <chrono>
#include <functional>
#include <string>
#include <thread>

/**
 * @class PeriodicTimer
 * @brief Executes a callback function at a fixed periodic interval in a separate thread.
 *
 * @details
 * This class uses a steady clock to trigger a user-supplied callback (`on_tick_`)
 * at a fixed period specified in seconds. The timer runs in a background worker thread
 * and can be started or stopped explicitly.
 *
 * The timer stops automatically on destruction.
 */
class PeriodicTimer {
    public:
        using Clock = std::chrono::steady_clock;
        using Sec   = std::chrono::duration<double>;
        using TickFn = std::function<void()>;

        /**
         * @fn PeriodicTimer::PeriodicTimer
         * @brief Construct a periodic timer with a given period, name, and callback.
         *
         * @param period_seconds [in] The interval between ticks, in seconds.
         * @param name [in] A human-readable name for the timer (used for identification/logging).
         * @param on_tick [in] Function to call at each tick interval.
         *
         * @note The callback will be executed in the context of the timer's worker thread.
         */
        PeriodicTimer(double period_seconds, std::string name, TickFn on_tick);

        /**
         * @fn PeriodicTimer::start
         * @brief Start the timer and begin executing the callback at fixed intervals.
         *
         * @details
         * - The timer starts immediately and waits for the first period before calling `on_tick_()`.
         * - Runs in a background thread until `stop()` is called or the object is destroyed.
         * - Thread-safe.
         */
        void start();

        /**
         * @fn PeriodicTimer::stop
         * @brief Stop the timer and wait for the worker thread to finish.
         *
         * @details
         * Safe to call multiple times; has no effect if the timer is not running.
         */
        void stop();

        /**
         * @fn PeriodicTimer::~PeriodicTimer
         * @brief Destructor that ensures the timer is stopped before destruction.
         */
        ~PeriodicTimer();
    
    private:
        double period_;
        std::string name_;
        TickFn on_tick_;
        std::atomic<bool> running_{false};
        std::thread worker_;
};
